#!/bin/bash
#
# This is the invocation that happens in the GitHub action ... it must be bash
#
bash prepareBPCartefacts.sh "$1" "$2" "$3" "$4"
