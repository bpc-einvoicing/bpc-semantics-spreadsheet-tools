sh validate.sh Core Invoice ../examples/Acme3099123-core-invoice.xml
sh validate.sh Core Invoice ../examples/MP-1-core-invoice.xml
sh validate.sh Core Invoice ../examples/MP-2-core-invoice.xml
