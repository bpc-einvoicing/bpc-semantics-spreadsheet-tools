
sh validate.sh Core Invoice Invoice-Core-test-bad-syntax.xml
sh validate.sh Core Invoice Invoice-Core-test-bad-model.xml
sh validate.sh Core Invoice Invoice-Core-test-bad-data.xml
sh validate.sh Core Invoice Invoice-Core-test-good.xml
